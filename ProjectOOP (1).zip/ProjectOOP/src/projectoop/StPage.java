package projectoop;
//==============================================================================================================================================================

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;
//==============================================================================================================================================================

class StPage extends JFrame implements ActionListener {
//==============================================================================================================================================================

    CardLayout cardLayout;
    JPanel mainPanel, STinfo, CourseGrades, Timetable, Logout;
    JButton stuInfoPage, coursesGradesPage, timatablePage, logoutBtn;
    static JLabel stuLab1, stuLab2, stuLab3, stuLab4, stuLab5, stuLab6, stuLab7, stuLab8, stuLab9, stuInfo1, stuInfo2, stuInfo3, stuInfo4, stuInfo5, stuInfo6, stuInfo7, stuInfo8, stuInfo9;
    DefaultTableModel tableModel, timetableModel;
    JTable courseTable, timetableTable;
//==============================================================================================================================================================

    public StPage() {
        setTitle("Student page");
        setSize(1000, 600);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);
//==============================================================================================================================================================
        // Sidebar Panel
        JPanel sidebar = new JPanel(null);
        ImageIcon sidex = new ImageIcon("side.jpg");
        final Image Sidexx = sidex.getImage();

        sidebar = new JPanel(null) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(Sidexx, 0, 0, getWidth(), getHeight(), this);
            }
        };

        sidebar.setBounds(0, 80, 200, 520);
        add(sidebar);

        stuInfoPage = new JButton("Student Info");
        coursesGradesPage = new JButton("Courses Grades");
        timatablePage = new JButton("Timetable");
        logoutBtn = new JButton("Logout");

        stuInfoPage.setBounds(5, 50, 190, 40);
        coursesGradesPage.setBounds(5, 100, 190, 40);
        timatablePage.setBounds(5, 150, 190, 40);
        logoutBtn.setBounds(5, 420, 190, 40);
        logoutBtn.setBackground(Color.RED);
        logoutBtn.setForeground(Color.WHITE);

        sidebar.add(stuInfoPage);
        sidebar.add(coursesGradesPage);
        sidebar.add(timatablePage);
        sidebar.add(logoutBtn);
//==============================================================================================================================================================
        // Header Panel
        JPanel header = new JPanel(null);

        ImageIcon head = new ImageIcon("head.jpg");
        final Image Head = head.getImage();

        header = new JPanel(null) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(Head, 0, 0, getWidth(), getHeight(), this);
            }
        };

        header.setBounds(0, 0, 1000, 80);
        add(header);

        JLabel headerLabel = new JLabel("- Student Page -");
        headerLabel.setFont(new Font("Arial", Font.BOLD, 25));
        headerLabel.setBounds(400, 25, 600, 30);
        headerLabel.setForeground(Color.WHITE);
        header.add(headerLabel);
//==============================================================================================================================================================
        // CardLayout
        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);
        mainPanel.setBounds(200, 80, 800, 520);
        add(mainPanel);
//==============================================================================================================================================================
        //Student Info 
        ImageIcon studentBgIcon = new ImageIcon("back.jpg");
        final Image studentBg = studentBgIcon.getImage();

        STinfo = new JPanel(null) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(studentBg, 0, 0, getWidth(), getHeight(), this);
            }
        };

        JLabel infoLabel = new JLabel("Student info page");
        infoLabel.setFont(new Font("Arial", Font.PLAIN, 20));
        infoLabel.setBounds(20, 20, 300, 30);
        STinfo.add(infoLabel);
        infoLabel.setForeground(Color.ORANGE);

        stuLab1 = new JLabel("ID :");
        stuLab1.setBounds(30, 100, 100, 40);
        stuLab1.setFont(new Font("Arial", Font.BOLD, 17));
        stuLab1.setForeground(Color.CYAN);
        stuInfo1 = new JLabel();
        stuInfo1.setBounds(180, 105, 320, 30);
        stuInfo1.setForeground(Color.WHITE);

        stuLab2 = new JLabel("Full name :");
        stuLab2.setBounds(30, 150, 150, 40);
        stuLab2.setFont(new Font("Arial", Font.BOLD, 17));
        stuLab2.setForeground(Color.CYAN);
        stuInfo2 = new JLabel();
        stuInfo2.setBounds(180, 155, 320, 30);
        stuInfo2.setForeground(Color.WHITE);

        stuLab3 = new JLabel("Stu mobile :");
        stuLab3.setBounds(30, 200, 150, 40);
        stuLab3.setFont(new Font("Arial", Font.BOLD, 17));
        stuLab3.setForeground(Color.CYAN);
        stuInfo3 = new JLabel();
        stuInfo3.setBounds(180, 205, 320, 30);
        stuInfo3.setForeground(Color.WHITE);

        stuLab4 = new JLabel("Parent mobile :");
        stuLab4.setBounds(30, 250, 150, 40);
        stuLab4.setFont(new Font("Arial", Font.BOLD, 17));
        stuLab4.setForeground(Color.CYAN);
        stuInfo4 = new JLabel();
        stuInfo4.setBounds(180, 255, 320, 30);
        stuInfo4.setForeground(Color.WHITE);

        stuLab5 = new JLabel("Stu e-mail :");
        stuLab5.setBounds(30, 300, 150, 40);
        stuLab5.setFont(new Font("Arial", Font.BOLD, 17));
        stuLab5.setForeground(Color.CYAN);
        stuInfo5 = new JLabel();
        stuInfo5.setBounds(180, 305, 320, 30);
        stuInfo5.setForeground(Color.WHITE);

        stuLab6 = new JLabel("Stu level :");
        stuLab6.setBounds(30, 350, 150, 40);
        stuLab6.setFont(new Font("Arial", Font.BOLD, 17));
        stuLab6.setForeground(Color.CYAN);
        stuInfo6 = new JLabel();
        stuInfo6.setBounds(180, 355, 320, 30);
        stuInfo6.setForeground(Color.WHITE);

        stuLab7 = new JLabel("Stu address:");
        stuLab7.setBounds(30, 400, 150, 40);
        stuLab7.setFont(new Font("Arial", Font.BOLD, 17));
        stuLab7.setForeground(Color.CYAN);
        stuInfo7 = new JLabel();
        stuInfo7.setBounds(180, 405, 320, 30);
        stuInfo7.setForeground(Color.WHITE);

        stuLab8 = new JLabel("Age :");
        stuLab8.setBounds(550, 100, 100, 40);
        stuLab8.setFont(new Font("Arial", Font.BOLD, 17));
        stuLab8.setForeground(Color.CYAN);
        stuInfo8 = new JLabel();
        stuInfo8.setBounds(630, 105, 100, 30);
        stuInfo8.setForeground(Color.WHITE);

        stuLab9 = new JLabel("Gender :");
        stuLab9.setBounds(550, 150, 100, 40);
        stuLab9.setFont(new Font("Arial", Font.BOLD, 17));
        stuLab9.setForeground(Color.CYAN);
        stuInfo9 = new JLabel();
        stuInfo9.setBounds(630, 155, 100, 30);
        stuInfo9.setForeground(Color.WHITE);

        stuInfo1.setFont(new Font(null, Font.BOLD, 18));
        stuInfo2.setFont(new Font(null, Font.BOLD, 18));
        stuInfo3.setFont(new Font(null, Font.BOLD, 18));
        stuInfo4.setFont(new Font(null, Font.BOLD, 18));
        stuInfo5.setFont(new Font(null, Font.BOLD, 18));
        stuInfo6.setFont(new Font(null, Font.BOLD, 18));
        stuInfo7.setFont(new Font(null, Font.BOLD, 18));
        stuInfo8.setFont(new Font(null, Font.BOLD, 18));
        stuInfo9.setFont(new Font(null, Font.BOLD, 18));

        STinfo.add(infoLabel);
        STinfo.add(stuLab1);
        STinfo.add(stuInfo1);
        STinfo.add(stuLab2);
        STinfo.add(stuInfo2);
        STinfo.add(stuLab3);
        STinfo.add(stuInfo3);
        STinfo.add(stuLab4);
        STinfo.add(stuInfo4);
        STinfo.add(stuLab5);
        STinfo.add(stuInfo5);
        STinfo.add(stuLab6);
        STinfo.add(stuInfo6);
        STinfo.add(stuLab7);
        STinfo.add(stuInfo7);
        STinfo.add(stuLab8);
        STinfo.add(stuInfo8);
        STinfo.add(stuLab9);
        STinfo.add(stuInfo9);
//==============================================================================================================================================================
        //Courses Grades
        ImageIcon coursesBgIcon = new ImageIcon("back.jpg");
        final Image coursesBg = coursesBgIcon.getImage();

        CourseGrades = new JPanel(null) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(coursesBg, 0, 0, getWidth(), getHeight(), this);
            }
        };

        JLabel coursesLabel = new JLabel("Courses Page");
        coursesLabel.setFont(new Font("Arial", Font.PLAIN, 20));
        coursesLabel.setBounds(20, 10, 300, 30);
        CourseGrades.add(coursesLabel);
        coursesLabel.setForeground(Color.ORANGE);

        tableModel = new DefaultTableModel();
        courseTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(courseTable);
        scrollPane.setBounds(80, 60, 500, 300);
        CourseGrades.add(scrollPane);

        tableModel.addColumn("Course ID");
        tableModel.addColumn("Course Name");
        tableModel.addColumn("Midterm Grade");
        tableModel.addColumn("Final Grade");

//==============================================================================================================================================================
        // Timetable 
        ImageIcon timetableBgIcon = new ImageIcon("back.jpg");
        final Image timetableBg = timetableBgIcon.getImage();

        Timetable = new JPanel(null) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(timetableBg, 0, 0, getWidth(), getHeight(), this);
            }
        };

        JLabel timetableLabel = new JLabel("Timetable Page");
        timetableLabel.setFont(new Font("Arial", Font.PLAIN, 20));
        timetableLabel.setBounds(20, 10, 300, 30);
        Timetable.add(timetableLabel);
        timetableLabel.setForeground(Color.ORANGE);

        timetableModel = new DefaultTableModel();
        timetableTable = new JTable(timetableModel);
        JScrollPane timetableScroll = new JScrollPane(timetableTable);
        timetableScroll.setBounds(180, 60, 300, 250);
        Timetable.add(timetableScroll);

        timetableModel.addColumn("Timetable");

//==============================================================================================================================================================
        //logout
        Logout = new JPanel(null);
        JLabel logoutLabel = new JLabel("You have been logged out.");
        logoutLabel.setFont(new Font("Arial", Font.PLAIN, 20));
        logoutLabel.setBounds(20, 10, 300, 30);
        Logout.add(logoutLabel);
//==============================================================================================================================================================
        // Add panels to CardLayout
        mainPanel.add(STinfo, "Student Info");
        mainPanel.add(CourseGrades, "Courses Grades");
        mainPanel.add(Timetable, "Timetable");
        mainPanel.add(Logout, "Logout");
//==============================================================================================================================================================
        // Add action listeners
        stuInfoPage.addActionListener(this);
        coursesGradesPage.addActionListener(this);
        timatablePage.addActionListener(this);
        logoutBtn.addActionListener(this);

        setVisible(true);
    }
//==============================================================================================================================================================

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == stuInfoPage) {
            cardLayout.show(mainPanel, "Student Info");
        } //==============================================================================================================================================================
        else if (e.getSource() == coursesGradesPage) {
            cardLayout.show(mainPanel, "Courses Grades");
            courseTable.setModel(Database.StuGrade(LoginPage.id));
        } //==============================================================================================================================================================
        else if (e.getSource() == timatablePage) {
            cardLayout.show(mainPanel, "Timetable");
            timetableTable.setModel(Database.getStudentCourses(LoginPage.id));
        } //==============================================================================================================================================================
        //logout action
        else if (e.getSource() == logoutBtn) {
            int acc = JOptionPane.showConfirmDialog(this, "Are you sure you want to logout?", "Logout Confirmation", JOptionPane.YES_NO_OPTION);
            if (acc == JOptionPane.YES_OPTION) {
                this.setVisible(false);
                new LoginPage();
            }
        }
    }
}
