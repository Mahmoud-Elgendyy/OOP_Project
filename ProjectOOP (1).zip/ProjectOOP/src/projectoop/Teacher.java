package projectoop;
//==============================================================================================================================================================

public class Teacher extends User {
//==============================================================================================================================================================

    private String FullName;
    private String TeacherMobile;
    private String Email;
    private String Address;
    private int age;
    private String Gender;
    private String CourseCode;
//==============================================================================================================================================================

    public Teacher() {
    }

    public Teacher(int id, String userName, String password) {
        super(id, userName, password);
    }
//==============================================================================================================================================================

    public String getFullName() {
        return FullName;
    }

    public void setFullName(String FullName) {
        this.FullName = FullName;
    }

    public String getTeacherMobile() {
        return TeacherMobile;
    }

    public void setTeacherMobile(String TeacherMobile) {
        this.TeacherMobile = TeacherMobile;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String Address) {
        this.Address = Address;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String Gender) {
        this.Gender = Gender;
    }

    public String getCourseCode() {
        return CourseCode;
    }

    public void setCourseCode(String CourseCode) {
        this.CourseCode = CourseCode;
    }
//==============================================================================================================================================================

    @Override
    public void displayFrame() {
        System.out.println("teacher");
    }
//==============================================================================================================================================================

}
